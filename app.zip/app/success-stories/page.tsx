"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trophy, MapPin, Quote, Search, Eye, Share2 } from "lucide-react"
import Link from "next/link"
import { Navbar } from "@/components/navbar"

export default function SuccessStoriesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedMetric, setSelectedMetric] = useState("all")

  const successStories = [
    {
      id: "1",
      title: "TechFest IIT Bombay: From Regional to Global Recognition",
      college: "Indian Institute of Technology Bombay",
      festival: "TechFest",
      category: "Technical",
      year: "2023",
      location: "Mumbai, Maharashtra",
      description:
        "How Asia's largest technical festival transformed their sponsorship strategy and achieved unprecedented success",
      metrics: {
        sponsorshipIncrease: "300%",
        attendanceGrowth: "150%",
        sponsorCount: "50+",
        revenue: "₹2.5 Cr",
      },
      testimonial: {
        quote:
          "FestConnect revolutionized how we approach sponsorships. The AI-powered matching connected us with sponsors we never would have found otherwise.",
        author: "Rahul Sharma",
        position: "Festival Director, TechFest 2023",
      },
      challenges: [
        "Limited sponsor outreach capabilities",
        "Difficulty in finding relevant tech sponsors",
        "Manual application tracking process",
      ],
      solutions: ["AI-powered sponsor matching", "Automated application management", "Real-time analytics dashboard"],
      results: [
        "300% increase in sponsorship value",
        "50+ new sponsor partnerships",
        "Reduced coordination time by 70%",
      ],
      image: "/placeholder.svg?height=400&width=600",
      featured: true,
    },
    {
      id: "2",
      title: "Mood Indigo: Digital-First Sponsorship Success",
      college: "Indian Institute of Technology Bombay",
      festival: "Mood Indigo",
      category: "Cultural",
      year: "2023",
      location: "Mumbai, Maharashtra",
      description:
        "India's largest college cultural festival adapted to digital-first sponsorships and achieved record-breaking partnerships",
      metrics: {
        sponsorshipIncrease: "250%",
        attendanceGrowth: "200%",
        sponsorCount: "75+",
        revenue: "₹4 Cr",
      },
      testimonial: {
        quote:
          "The platform's comprehensive analytics helped us demonstrate clear ROI to sponsors, leading to long-term partnerships.",
        author: "Priya Patel",
        position: "Sponsorship Head, Mood Indigo 2023",
      },
      challenges: [
        "Shift to digital-first events",
        "Proving ROI for virtual sponsorships",
        "Managing increased sponsor applications",
      ],
      solutions: ["Digital sponsorship packages", "Real-time engagement tracking", "Streamlined application workflow"],
      results: [
        "75+ digital sponsor partnerships",
        "250% increase in sponsorship revenue",
        "98% sponsor satisfaction rate",
      ],
      image: "/placeholder.svg?height=400&width=600",
      featured: true,
    },
    {
      id: "3",
      title: "Festember NIT Trichy: Regional Festival Goes National",
      college: "National Institute of Technology Trichy",
      festival: "Festember",
      category: "Multi-Genre",
      year: "2023",
      location: "Trichy, Tamil Nadu",
      description:
        "A regional festival's journey to attracting national sponsors and scaling their impact across South India",
      metrics: {
        sponsorshipIncrease: "400%",
        attendanceGrowth: "180%",
        sponsorCount: "35+",
        revenue: "₹1.2 Cr",
      },
      testimonial: {
        quote:
          "FestConnect helped us break out of our regional bubble and connect with national brands that aligned with our values.",
        author: "Arjun Kumar",
        position: "Festival Coordinator, Festember 2023",
      },
      challenges: [
        "Limited brand recognition outside region",
        "Competing with premier institutes",
        "Small sponsorship team",
      ],
      solutions: [
        "Enhanced festival profile visibility",
        "Targeted sponsor recommendations",
        "Professional sponsorship materials",
      ],
      results: [
        "First-time national sponsor partnerships",
        "400% increase in sponsorship value",
        "Featured in national media coverage",
      ],
      image: "/placeholder.svg?height=400&width=600",
      featured: false,
    },
    {
      id: "4",
      title: "Alcheringa IIT Guwahati: Northeast India's Cultural Revolution",
      college: "Indian Institute of Technology Guwahati",
      festival: "Alcheringa",
      category: "Cultural",
      year: "2023",
      location: "Guwahati, Assam",
      description:
        "How Northeast India's premier cultural festival leveraged technology to attract pan-India sponsorships",
      metrics: {
        sponsorshipIncrease: "350%",
        attendanceGrowth: "220%",
        sponsorCount: "40+",
        revenue: "₹1.8 Cr",
      },
      testimonial: {
        quote:
          "The platform helped us showcase the unique cultural value proposition of Northeast India to sponsors across the country.",
        author: "Sneha Devi",
        position: "Cultural Secretary, Alcheringa 2023",
      },
      challenges: [
        "Geographic isolation from major markets",
        "Limited sponsor awareness of Northeast",
        "Cultural positioning challenges",
      ],
      solutions: [
        "Cultural heritage storytelling",
        "Virtual sponsor engagement sessions",
        "Regional diversity showcase",
      ],
      results: [
        "40+ new sponsor partnerships",
        "350% sponsorship revenue growth",
        "Established as Northeast cultural hub",
      ],
      image: "/placeholder.svg?height=400&width=600",
      featured: false,
    },
    {
      id: "5",
      title: "Shaastra IIT Madras: Innovation Meets Industry",
      college: "Indian Institute of Technology Madras",
      festival: "Shaastra",
      category: "Technical",
      year: "2023",
      location: "Chennai, Tamil Nadu",
      description:
        "South India's largest technical festival created meaningful industry partnerships through strategic sponsor matching",
      metrics: {
        sponsorshipIncrease: "280%",
        attendanceGrowth: "160%",
        sponsorCount: "45+",
        revenue: "₹2.1 Cr",
      },
      testimonial: {
        quote:
          "The quality of sponsor matches was exceptional. We found partners who were genuinely interested in our technical innovations.",
        author: "Vikram Reddy",
        position: "Technical Head, Shaastra 2023",
      },
      challenges: [
        "Aligning technical content with sponsor goals",
        "Competition from established festivals",
        "Demonstrating innovation value",
      ],
      solutions: [
        "Innovation showcase platforms",
        "Industry-academia collaboration events",
        "Technical workshop sponsorships",
      ],
      results: ["45+ industry partnerships", "280% increase in sponsorship value", "Launched 5 startup collaborations"],
      image: "/placeholder.svg?height=400&width=600",
      featured: false,
    },
    {
      id: "6",
      title: "Oasis BITS Pilani: Desert Bloom Success Story",
      college: "Birla Institute of Technology and Science Pilani",
      festival: "Oasis",
      category: "Cultural",
      year: "2023",
      location: "Pilani, Rajasthan",
      description:
        "How a desert campus festival attracted major sponsors through unique positioning and authentic storytelling",
      metrics: {
        sponsorshipIncrease: "320%",
        attendanceGrowth: "190%",
        sponsorCount: "38+",
        revenue: "₹1.6 Cr",
      },
      testimonial: {
        quote:
          "FestConnect helped us turn our unique desert location into a compelling brand story that sponsors loved.",
        author: "Ananya Singh",
        position: "Festival President, Oasis 2023",
      },
      challenges: [
        "Remote location disadvantage",
        "Limited local sponsor base",
        "Logistics and accessibility concerns",
      ],
      solutions: [
        "Unique desert experience positioning",
        "Virtual sponsor engagement options",
        "Comprehensive logistics support",
      ],
      results: [
        "38+ national sponsor partnerships",
        "320% sponsorship revenue increase",
        "Established as premium desert festival",
      ],
      image: "/placeholder.svg?height=400&width=600",
      featured: false,
    },
  ]

  const filteredStories = successStories.filter((story) => {
    const matchesSearch =
      story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      story.college.toLowerCase().includes(searchTerm.toLowerCase()) ||
      story.festival.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || story.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleShare = (story: any) => {
    if (navigator.share) {
      navigator.share({
        title: story.title,
        text: story.description,
        url: window.location.href + `#${story.id}`,
      })
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(window.location.href + `#${story.id}`)
      alert("Link copied to clipboard!")
    }
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(34,197,94,0.1),transparent_50%)]"></div>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-400/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-green-400/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-300 mb-6">
            Success{" "}
            <span className="bg-gradient-to-r from-green-400 to-green-300 bg-clip-text text-transparent">Stories</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Discover how college festivals across India have transformed their sponsorship strategies and achieved
            remarkable success with FestConnect.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">2500+</div>
              <div className="text-gray-400">Festivals Transformed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">300%</div>
              <div className="text-gray-400">Avg. Revenue Increase</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">₹50Cr+</div>
              <div className="text-gray-400">Total Value Created</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">95%</div>
              <div className="text-gray-400">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-gray-900/50 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search success stories..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Festival Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Technical">Technical</SelectItem>
                <SelectItem value="Cultural">Cultural</SelectItem>
                <SelectItem value="Multi-Genre">Multi-Genre</SelectItem>
                <SelectItem value="Business">Business</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedMetric} onValueChange={setSelectedMetric}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Success Metric" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Metrics</SelectItem>
                <SelectItem value="revenue">Revenue Growth</SelectItem>
                <SelectItem value="sponsors">Sponsor Count</SelectItem>
                <SelectItem value="attendance">Attendance Growth</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Featured Stories */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Featured Success Stories</h2>
            <p className="text-xl text-gray-400">Inspiring transformations from festivals across India</p>
          </div>

          <div className="space-y-12">
            {filteredStories
              .filter((story) => story.featured)
              .map((story, index) => (
                <Card
                  key={story.id}
                  className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow overflow-hidden"
                >
                  <div className={`lg:flex ${index % 2 === 1 ? "lg:flex-row-reverse" : ""}`}>
                    <div className="lg:w-1/2">
                      <img
                        src={story.image || "/placeholder.svg"}
                        alt={story.title}
                        className="w-full h-64 lg:h-full object-cover"
                      />
                    </div>
                    <div className="lg:w-1/2 p-8">
                      <div className="flex items-center justify-between mb-4">
                        <Badge className="bg-green-600">Featured</Badge>
                        <Button variant="ghost" size="sm" onClick={() => handleShare(story)}>
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <h3 className="text-2xl font-bold text-white mb-2">{story.title}</h3>
                      <div className="flex items-center text-gray-400 mb-4">
                        <MapPin className="h-4 w-4 mr-1" />
                        {story.college}
                      </div>

                      <p className="text-gray-400 mb-6">{story.description}</p>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-400">{story.metrics.sponsorshipIncrease}</div>
                          <div className="text-sm text-gray-400">Revenue Increase</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-400">{story.metrics.sponsorCount}</div>
                          <div className="text-sm text-gray-400">Sponsors</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-400">{story.metrics.attendanceGrowth}</div>
                          <div className="text-sm text-gray-400">Attendance Growth</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-400">{story.metrics.revenue}</div>
                          <div className="text-sm text-gray-400">Total Revenue</div>
                        </div>
                      </div>

                      <div className="bg-gray-800 p-4 rounded-lg mb-6">
                        <Quote className="h-6 w-6 text-green-400 mb-2" />
                        <p className="text-gray-300 italic mb-3">"{story.testimonial.quote}"</p>
                        <div className="text-sm">
                          <div className="font-semibold text-white">{story.testimonial.author}</div>
                          <div className="text-gray-400">{story.testimonial.position}</div>
                        </div>
                      </div>

                      <Button asChild>
                        <Link href={`/success-stories/${story.id}`}>
                          <Eye className="h-4 w-4 mr-2" />
                          Read Full Story
                        </Link>
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
          </div>
        </div>
      </section>

      {/* All Stories Grid */}
      <section className="py-20 bg-gray-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-8">All Success Stories</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredStories
              .filter((story) => !story.featured)
              .map((story) => (
                <Card key={story.id} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <img
                      src={story.image || "/placeholder.svg"}
                      alt={story.title}
                      className="w-full h-48 object-cover"
                    />
                    <Badge className="absolute top-4 left-4" variant="outline">
                      {story.category}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute top-4 right-4 bg-white/80 hover:bg-white"
                      onClick={() => handleShare(story)}
                    >
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <CardHeader>
                    <CardTitle className="text-lg text-white">{story.title}</CardTitle>
                    <CardDescription className="flex items-center text-gray-400">
                      <MapPin className="h-4 w-4 mr-1" />
                      {story.college}
                    </CardDescription>
                  </CardHeader>

                  <CardContent>
                    <p className="text-gray-400 text-sm mb-4">{story.description}</p>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-400">{story.metrics.sponsorshipIncrease}</div>
                        <div className="text-xs text-gray-400">Revenue ↑</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-400">{story.metrics.sponsorCount}</div>
                        <div className="text-xs text-gray-400">Sponsors</div>
                      </div>
                    </div>

                    <Button className="w-full" variant="outline" asChild>
                      <Link href={`/success-stories/${story.id}`}>Read Story</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
          </div>

          {filteredStories.length === 0 && (
            <div className="text-center py-12">
              <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-400 mb-2">No stories found</h3>
              <p className="text-gray-500">Try adjusting your search criteria</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready to Write Your Success Story?</h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Join thousands of festivals that have transformed their sponsorship strategies with EventNest.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/college/register">List Your Festival</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-green-600"
              asChild
            >
              <Link href="/sponsor/register">Become a Sponsor</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Trophy className="h-6 w-6 text-green-400" />
                <span className="ml-2 text-xl font-bold">FestConnect</span>
              </div>
              <p className="text-gray-400">Revolutionizing event partnerships across India.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Success Stories</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/success-stories" className="hover:text-white">
                    All Stories
                  </Link>
                </li>
                <li>
                  <Link href="/success-stories?category=technical" className="hover:text-white">
                    Technical Festivals
                  </Link>
                </li>
                <li>
                  <Link href="/success-stories?category=cultural" className="hover:text-white">
                    Cultural Festivals
                  </Link>
                </li>
                <li>
                  <Link href="/case-studies" className="hover:text-white">
                    Case Studies
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Platform</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/sponsorships" className="hover:text-white">
                    Find Events
                  </Link>
                </li>
                <li>
                  <Link href="/college/register" className="hover:text-white">
                    List Festival
                  </Link>
                </li>
                <li>
                  <Link href="/resources" className="hover:text-white">
                    Resources
                  </Link>
                </li>
                <li>
                  <Link href="/roi-calculator" className="hover:text-white">
                    ROI Calculator
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-white">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    Privacy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 FestConnect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
