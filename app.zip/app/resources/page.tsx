"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Download, Video, Users, Target, TrendingUp, Search, Calendar, Clock, Eye } from "lucide-react"
import Link from "next/link"
import { Navbar } from "@/components/navbar"

export default function ResourcesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const guides = [
    {
      id: "1",
      title: "Complete Guide to Festival Sponsorship",
      description: "Everything you need to know about securing sponsors for your college festival",
      category: "Festival Management",
      type: "PDF Guide",
      downloadUrl: "#",
      readTime: "15 min",
      downloads: 2500,
      featured: true,
    },
    {
      id: "2",
      title: "Sponsorship Package Creation Template",
      description: "Ready-to-use templates for creating compelling sponsorship packages",
      category: "Templates",
      type: "Template",
      downloadUrl: "#",
      readTime: "5 min",
      downloads: 1800,
      featured: true,
    },
    {
      id: "3",
      title: "ROI Measurement for Event Sponsors",
      description: "How to measure and demonstrate the return on investment for event sponsorships",
      category: "Analytics",
      type: "PDF Guide",
      downloadUrl: "#",
      readTime: "12 min",
      downloads: 1200,
      featured: false,
    },
    {
      id: "4",
      title: "Festival Marketing Checklist",
      description: "Step-by-step checklist to promote your festival effectively",
      category: "Marketing",
      type: "Checklist",
      downloadUrl: "#",
      readTime: "8 min",
      downloads: 950,
      featured: false,
    },
  ]

  const webinars = [
    {
      id: "1",
      title: "Building Successful Festival-Sponsor Partnerships",
      description: "Learn from industry experts about creating lasting partnerships",
      date: "2024-02-15",
      duration: "45 min",
      speaker: "Rahul Gupta, Head of Partnerships",
      registrationUrl: "#",
      status: "upcoming",
    },
    {
      id: "2",
      title: "Digital Marketing for College Festivals",
      description: "Master social media and digital marketing strategies for events",
      date: "2024-01-20",
      duration: "60 min",
      speaker: "Priya Sharma, Marketing Director",
      registrationUrl: "#",
      status: "recorded",
    },
    {
      id: "3",
      title: "Sponsorship Negotiation Masterclass",
      description: "Advanced techniques for negotiating better sponsorship deals",
      date: "2024-01-05",
      duration: "50 min",
      speaker: "Arjun Patel, Business Development",
      registrationUrl: "#",
      status: "recorded",
    },
  ]

  const caseStudies = [
    {
      id: "1",
      title: "How TechFest IIT Bombay Increased Sponsorship by 300%",
      description:
        "A detailed case study of how India's largest technical festival transformed their sponsorship strategy",
      college: "IIT Bombay",
      festival: "TechFest",
      results: "300% increase in sponsorship value",
      readUrl: "#",
      category: "Technical Festival",
    },
    {
      id: "2",
      title: "Mood Indigo's Digital Transformation Success",
      description: "How Asia's largest college cultural festival adapted to digital-first sponsorships",
      college: "IIT Bombay",
      festival: "Mood Indigo",
      results: "50+ new digital sponsors",
      readUrl: "#",
      category: "Cultural Festival",
    },
    {
      id: "3",
      title: "Regional Festival Goes National: A Success Story",
      description: "How a small regional festival attracted national sponsors and scaled up",
      college: "NIT Trichy",
      festival: "Festember",
      results: "Scaled from regional to national",
      readUrl: "#",
      category: "Multi-Genre Festival",
    },
  ]

  const tools = [
    {
      id: "1",
      title: "Sponsorship ROI Calculator",
      description: "Calculate the potential return on investment for your sponsorship campaigns",
      type: "Calculator",
      url: "/tools/roi-calculator",
      icon: <TrendingUp className="h-6 w-6 text-green-600" />,
    },
    {
      id: "2",
      title: "Festival Budget Planner",
      description: "Plan and track your festival budget with our comprehensive tool",
      type: "Planner",
      url: "/tools/budget-planner",
      icon: <Target className="h-6 w-6 text-blue-600" />,
    },
    {
      id: "3",
      title: "Sponsor Outreach Template Generator",
      description: "Generate personalized outreach emails for potential sponsors",
      type: "Generator",
      url: "/tools/email-generator",
      icon: <Users className="h-6 w-6 text-purple-600" />,
    },
  ]

  const filteredGuides = guides.filter((guide) => {
    const matchesSearch =
      guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guide.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || guide.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(34,197,94,0.1),transparent_50%)]"></div>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-400/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-green-400/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-300 mb-6">
            Festival{" "}
            <span className="bg-gradient-to-r from-green-400 to-green-300 bg-clip-text text-transparent">
              Resources
            </span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Everything you need to organize successful festivals and build meaningful sponsorship partnerships. Free
            guides, templates, tools, and expert insights.
          </p>
          <div className="flex justify-center">
            <div className="relative max-w-md w-full">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search resources..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-900 border-gray-700 text-white placeholder-gray-400"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="guides" className="space-y-8">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="guides">Guides & Templates</TabsTrigger>
              <TabsTrigger value="webinars">Webinars</TabsTrigger>
              <TabsTrigger value="case-studies">Case Studies</TabsTrigger>
              <TabsTrigger value="tools">Tools</TabsTrigger>
            </TabsList>

            <TabsContent value="guides" className="space-y-8">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Guides & Templates</h2>
                <div className="flex gap-2">
                  <Button
                    variant={selectedCategory === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory("all")}
                  >
                    All
                  </Button>
                  <Button
                    variant={selectedCategory === "Festival Management" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory("Festival Management")}
                  >
                    Festival Management
                  </Button>
                  <Button
                    variant={selectedCategory === "Templates" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory("Templates")}
                  >
                    Templates
                  </Button>
                  <Button
                    variant={selectedCategory === "Marketing" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory("Marketing")}
                  >
                    Marketing
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredGuides.map((guide) => (
                  <Card key={guide.id} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <Badge variant={guide.featured ? "default" : "secondary"}>{guide.type}</Badge>
                        {guide.featured && <Badge className="bg-indigo-600">Featured</Badge>}
                      </div>
                      <CardTitle className="text-lg text-white">{guide.title}</CardTitle>
                      <CardDescription className="text-gray-400">{guide.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center text-sm text-gray-400 mb-4">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {guide.readTime}
                        </div>
                        <div className="flex items-center">
                          <Download className="h-4 w-4 mr-1" />
                          {guide.downloads.toLocaleString()}
                        </div>
                      </div>
                      <Button className="w-full" asChild>
                        <Link href={guide.downloadUrl}>
                          <Download className="h-4 w-4 mr-2" />
                          Download Free
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="webinars" className="space-y-8">
              <h2 className="text-2xl font-bold text-white">Expert Webinars</h2>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {webinars.map((webinar) => (
                  <Card key={webinar.id} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <Badge variant={webinar.status === "upcoming" ? "default" : "secondary"}>
                          {webinar.status === "upcoming" ? "Upcoming" : "Recorded"}
                        </Badge>
                        <div className="text-sm text-gray-400">{webinar.duration}</div>
                      </div>
                      <CardTitle className="text-xl text-white">{webinar.title}</CardTitle>
                      <CardDescription className="text-gray-400">{webinar.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center text-sm text-gray-400">
                          <Calendar className="h-4 w-4 mr-2" />
                          {new Date(webinar.date).toLocaleDateString()}
                        </div>
                        <div className="flex items-center text-sm text-gray-400">
                          <Users className="h-4 w-4 mr-2" />
                          {webinar.speaker}
                        </div>
                        <Button className="w-full" asChild>
                          <Link href={webinar.registrationUrl}>
                            {webinar.status === "upcoming" ? (
                              <>
                                <Calendar className="h-4 w-4 mr-2" />
                                Register Now
                              </>
                            ) : (
                              <>
                                <Video className="h-4 w-4 mr-2" />
                                Watch Recording
                              </>
                            )}
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="case-studies" className="space-y-8">
              <h2 className="text-2xl font-bold text-white">Success Stories</h2>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {caseStudies.map((study) => (
                  <Card key={study.id} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <Badge variant="outline" className="w-fit mb-2">
                        {study.category}
                      </Badge>
                      <CardTitle className="text-xl text-white">{study.title}</CardTitle>
                      <CardDescription className="text-gray-400">{study.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-white">College:</span>
                            <p className="text-gray-400">{study.college}</p>
                          </div>
                          <div>
                            <span className="font-medium text-white">Festival:</span>
                            <p className="text-gray-400">{study.festival}</p>
                          </div>
                        </div>
                        <div className="bg-green-50 p-3 rounded-lg">
                          <span className="font-medium text-green-900">Results:</span>
                          <p className="text-green-700">{study.results}</p>
                        </div>
                        <Button className="w-full" variant="outline" asChild>
                          <Link href={study.readUrl}>
                            <Eye className="h-4 w-4 mr-2" />
                            Read Full Case Study
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="tools" className="space-y-8">
              <h2 className="text-2xl font-bold text-white">Free Tools</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tools.map((tool) => (
                  <Card key={tool.id} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center mb-4">
                        {tool.icon}
                        <Badge variant="outline" className="ml-auto">
                          {tool.type}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl text-white">{tool.title}</CardTitle>
                      <CardDescription className="text-gray-400">{tool.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button className="w-full" asChild>
                        <Link href={tool.url}>Use Tool</Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20 bg-indigo-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Stay Updated with New Resources</h2>
          <p className="text-xl text-indigo-100 mb-8 max-w-2xl mx-auto">
            Get notified when we publish new guides, templates, and tools to help you succeed.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Input placeholder="Enter your email" className="bg-white" />
            <Button variant="secondary">Subscribe</Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Trophy className="h-6 w-6 text-indigo-400" />
                <span className="ml-2 text-xl font-bold">FestConnect</span>
              </div>
              <p className="text-gray-400">Revolutionizing event partnerships across India.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Resources</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/resources" className="hover:text-white">
                    All Resources
                  </Link>
                </li>
                <li>
                  <Link href="/resources#guides" className="hover:text-white">
                    Guides
                  </Link>
                </li>
                <li>
                  <Link href="/resources#webinars" className="hover:text-white">
                    Webinars
                  </Link>
                </li>
                <li>
                  <Link href="/resources#tools" className="hover:text-white">
                    Tools
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Platform</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/sponsorships" className="hover:text-white">
                    Find Events
                  </Link>
                </li>
                <li>
                  <Link href="/college/register" className="hover:text-white">
                    List Festival
                  </Link>
                </li>
                <li>
                  <Link href="/success-stories" className="hover:text-white">
                    Success Stories
                  </Link>
                </li>
                <li>
                  <Link href="/case-studies" className="hover:text-white">
                    Case Studies
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-white">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    Privacy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 FestConnect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
