"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Search,
  MapPin,
  Calendar,
  Users,
  Trophy,
  Heart,
  TrendingUp,
  Star,
  ArrowRight,
  Send,
  Download,
} from "lucide-react"
import { Navbar } from "@/components/navbar"
import Particles from "@tsparticles/react"
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast"
import mongoose from "mongoose";

interface Festival {
  id: string
  name: string
  college: string
  location: string
  date: string
  endDate: string
  attendance: string
  type: string
  category: string
  packages: Array<{
    name: string
    price: string
    benefits: string[]
  }>
  image: string
  featured: boolean
  trending: boolean
  rating: number
  previousSponsors: string[]
  description: string
  saved: boolean
  brochurePdf?: {
    url: string;
    filename: string;
  };
  eventTypes?: string[];
  budgetRange?: string;
}

interface Event {
  _id: string;
  title: string;
  description: string;
  date: string;
  venue: string;
  expectedAttendance: number;
  sponsorshipTiers: string;
  college: {
    collegeName: string;
    location: string;
  };
  brochurePdf?: {
    url: string;
    filename: string;
  };
  eventTypes?: string[];
  budgetRange?: string;
}

export default function SponsorshipsPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const { toast } = useToast();
  const [festivals, setFestivals] = useState<Festival[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedType, setSelectedType] = useState("all")
  const [selectedBudget, setSelectedBudget] = useState("all")
  const [selectedLocation, setSelectedLocation] = useState("all")
  const [sortBy, setSortBy] = useState("relevance")
  const [applyDialog, setApplyDialog] = useState<{ open: boolean; festival: Festival | null }>({
    open: false,
    festival: null,
  })
  const [applicationForm, setApplicationForm] = useState({
    package: "",
    message: "",
    companyName: "",
    email: "",
  })
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [availableLocations, setAvailableLocations] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchEvents = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch('/api/events');
        const data = await response.json();

        if (!data || !Array.isArray(data.events)) {
          throw new Error('Invalid response format: events array expected');
        }

        const locations = [...new Set(data.events.map((event: Event) => 
          event.venue || "Location not specified"
        ))].filter(Boolean) as string[];
        
        setAvailableLocations(locations);

        const formattedEvents = data.events.map((event: Event) => ({
          id: event._id,
          name: event.title,
          college: typeof event.college === 'string' ? event.college : (event.college?.collegeName || "Unknown College"),
          location: event.venue || "Location not specified",
          date: new Date(event.date).toISOString(),
          endDate: new Date(event.date).toISOString(),
          attendance: `${event.expectedAttendance || 0}+`,
          type: event.eventTypes && event.eventTypes.length > 0 ? event.eventTypes[0] : "College Event",
          category: "Event",
          packages: [{
            name: "Sponsorship",
            price: event.sponsorshipTiers || "Contact for pricing",
            benefits: [event.description || "No description available"]
          }],
          image: '',
          featured: false,
          trending: false,
          rating: 5,
          previousSponsors: [],
          description: event.description || "No description available",
          saved: false,
          brochurePdf: event.brochurePdf,
          eventTypes: event.eventTypes || [],
          budgetRange: event.budgetRange || "Contact for details",
        }));

        setFestivals(formattedEvents);
      } catch (error) {
        console.error('Error fetching events:', error);
        const errorMessage = error instanceof Error
          ? `Failed to load events: ${error.message}`
          : 'An unexpected error occurred while loading events';
        
        setError(errorMessage);
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, [toast]);

  // Show error state if there's an error
  if (error) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Error</h2>
          <p className="text-red-400 mb-4">{error}</p>
          <Button 
            onClick={() => window.location.reload()}
            className="bg-green-400 hover:bg-green-500 text-black"
          >
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-400 mx-auto mb-4"></div>
          <p className="text-lg">Loading events...</p>
        </div>
      </div>
    );
  }

  if (!loading && festivals.length === 0) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">No Events Found</h2>
          <p className="text-gray-400">Check back later for upcoming events.</p>
        </div>
      </div>
    );
  }

  const handleSaveFestival = (festivalId: string) => {
    const updatedFestivals = festivals.map((f) => (f.id === festivalId ? { ...f, saved: !f.saved } : f))
    setFestivals(updatedFestivals)
  }

  const handleApplyForSponsorship = async () => {
    if (!session?.user?.email) {
      toast({
        title: "Error",
        description: "You must be logged in to apply",
        variant: "destructive",
      });
      return;
    }

    if (applyDialog.festival && applicationForm.package) {
      try {
        const applicationData = {
          event: applyDialog.festival.id,
          packageName: applicationForm.package,
          message: applicationForm.message || '',
          sponsorEmail: session.user.email,
          companyName: applicationForm.companyName || session.user.name,
        };

        const res = await fetch('/api/applications/create', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(applicationData),
        });

        const data = await res.json();

        if (!res.ok) {
          // Check for duplicate application error
          if (data.error?.includes('duplicate key error') || data.error?.includes('already applied')) {
            toast({
              title: "Already Applied",
              description: "You have already submitted an application for this event",
              variant: "destructive",
            });
          } else {
            throw new Error(data.error || 'Failed to submit application');
          }
          return;
        }

        toast({
          title: "Success",
          description: "Application submitted successfully!",
          variant: "success",
        });

        setApplyDialog({ open: false, festival: null });
        setApplicationForm({
          package: "",
          message: "",
          companyName: "",
          email: "",
        });
      } catch (error: any) {
        console.error('Application submission error:', error);
        toast({
          title: "Error",
          description: "Failed to submit application. You might have already applied for this event.",
          variant: "destructive",
        });
      }
    }
  };

  const handleDownloadBrochure = (festival: Festival) => {
    if (festival.brochurePdf?.url) {
      // Open PDF in new tab directly using public URL
      window.open(festival.brochurePdf.url, '_blank');
    } else {
      alert('No brochure available for this event');
    }
  };

  const filteredFestivals = festivals.filter((festival: Festival) => {
    const matchesSearch = searchTerm === "" || 
      festival.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      festival.college.toLowerCase().includes(searchTerm.toLowerCase()) ||
      festival.location.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = selectedType === "all" || 
      (festival.eventTypes && festival.eventTypes.includes(selectedType));

    const matchesLocation = selectedLocation === "all" || 
      festival.location.toLowerCase() === selectedLocation.toLowerCase();

    const matchesBudget = selectedBudget === "all" || 
      festival.budgetRange === selectedBudget;

    return matchesSearch && matchesType && matchesLocation && matchesBudget;
  });

  // Sort festivals
  const sortedFestivals = [...filteredFestivals].sort((a, b) => {
    switch (sortBy) {
      case "date":
        return new Date(a.date).getTime() - new Date(b.date).getTime()
      case "budget":
        const aMinPrice = Math.min(...a.packages.map((p) => Number.parseInt(p.price.replace(/[₹,]/g, ""))))
        const bMinPrice = Math.min(...b.packages.map((p) => Number.parseInt(p.price.replace(/[₹,]/g, ""))))
        return aMinPrice - bMinPrice
      case "attendance":
        const aAttendance = Number.parseInt(a.attendance.replace(/[+,]/g, ""))
        const bAttendance = Number.parseInt(b.attendance.replace(/[+,]/g, ""))
        return bAttendance - aAttendance
      default:
        // Relevance: featured first, then trending
        if (a.featured && !b.featured) return -1
        if (!a.featured && b.featured) return 1
        if (a.trending && !b.trending) return -1
        if (!a.trending && b.trending) return 1
        return 0
    }
  })

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* Particles Background */}
      <div className="absolute inset-0 -z-10">
        <Particles
          id="tsparticles-home"
          options={{
            fullScreen: false,
            background: { color: "transparent" },
            fpsLimit: 60,
            particles: {
              number: { value: 120, density: { enable: true } },
              color: { value: ["#22c55e", "#a7f3d0", "#bbf7d0", "#16a34a"] },
              shape: { type: "circle" },
              opacity: { value: 0.5 },
              size: { value: 4 },
              move: { enable: true, speed: 1.5, direction: "none", outModes: { default: "out" } },
              links: { enable: true, color: "#22c55e", distance: 120, opacity: 0.3, width: 1.5 },
            },
            detectRetina: true,
          }}
        />
        {/* Fallback animated background if particles fail */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-400/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-green-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute inset-0 bg-gradient-to-br from-green-400/10 to-transparent animate-gradient" style={{zIndex: -1}}></div>
        </div>
      </div>
      {/* Header */}
      <Navbar />
      {/* Main Content */}
      <div className="max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8 py-12"> {/* Changed max-w-7xl to max-w-[90rem] */}
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white">Sponsorship</span> <span className="text-green-400">Opportunities</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Discover premium college fests and events across India. Connect with your target audience through
            strategic partnerships.
          </p>
        </div>

        {/* Search and Filters */}
        <Card className="bg-gray-900 border-gray-800 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Search festivals, colleges, or locations..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400"
                  />
                </div>
              </div>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-full lg:w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Festival Type" />
                </SelectTrigger>
                <SelectContent 
                  side="bottom" 
                  position="item-aligned" 
                  className="bg-gray-800 border-gray-700"
                >
                  <SelectItem value="all" className="text-white">All Types</SelectItem>
                  <SelectItem value="technical" className="text-white">Technical</SelectItem>
                  <SelectItem value="cultural" className="text-white">Cultural</SelectItem>
                  <SelectItem value="business" className="text-white">Business</SelectItem>
                  <SelectItem value="sports" className="text-white">Sports</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger className="w-full lg:w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent 
                  side="bottom" 
                  position="item-aligned" 
                  className="bg-gray-800 border-gray-700"
                >
                  <SelectItem value="all" className="text-white">All Locations</SelectItem>
                  {availableLocations.map((location) => (
                    <SelectItem key={location} value={location.toLowerCase()} className="text-white">
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedBudget} onValueChange={setSelectedBudget}>
                <SelectTrigger className="w-full lg:w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Budget Range" />
                </SelectTrigger>
                <SelectContent 
                  side="bottom" 
                  position="item-aligned" 
                  className="bg-gray-800 border-gray-700"
                >
                  <SelectItem value="all" className="text-white">All Budgets</SelectItem>
                  <SelectItem value="50k-1l" className="text-white">Under ₹1L</SelectItem>
                  <SelectItem value="1l-2.5l" className="text-white">₹1L - ₹2.5L</SelectItem>
                  <SelectItem value="2.5l-5l" className="text-white">₹2.5L - ₹5L</SelectItem>
                  <SelectItem value="5l+" className="text-white">Above ₹5L</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Results Count and Sort */}
        <div className="flex justify-between items-center mb-8">
          <p className="text-gray-400">
            Showing {sortedFestivals.length} of {festivals.length} festivals
          </p>
          <div className="flex items-center space-x-2">
            <span className="text-gray-400">Sort by:</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40 bg-gray-800 border-gray-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent 
                side="bottom" 
                position="item-aligned" 
                className="bg-gray-800 border-gray-700"
              >
                <SelectItem value="relevance" className="text-white">Relevance</SelectItem>
                <SelectItem value="date" className="text-white">Date</SelectItem>
                <SelectItem value="budget" className="text-white">Budget</SelectItem>
                <SelectItem value="attendance" className="text-white">Attendance</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Festival Listings - Changed to grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"> {/* Changed from space-y-8 to grid */}
          {sortedFestivals.map((festival) => (
            <Card
              key={festival.id}
              className="bg-gray-900 border-gray-800 hover:border-green-400/50 transition-all duration-300 overflow-hidden rounded-xl h-full flex flex-col" // Added h-full and flex flex-col
            >
              {/* Accent Header Line */}
              <div className="h-2 w-full bg-gradient-to-r from-green-400 to-emerald-500" />

              <div className="p-6 flex flex-col flex-grow"> {/* Added flex-grow */}
                {/* Festival Details */}
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">{festival.name}</h3>
                    <p className="text-gray-400 mb-2">{festival.college}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-400 flex-wrap">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {festival.location}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {new Date(festival.date).toLocaleDateString()} – {new Date(festival.endDate).toLocaleDateString()}
                      </div>
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-1" />
                        {festival.attendance}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-800"
                      onClick={() => handleSaveFestival(festival.id)}
                    >
                      {festival.saved ? <Heart className="h-4 w-4 text-red-500" /> : <Heart className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                {/* Previous Sponsors */}
                <div className="mb-4">
                  <h4 className="text-white font-semibold mb-2">Previous Sponsors:</h4>
                  <div className="flex flex-wrap gap-2">
                    {festival.previousSponsors.map((sponsor, index) => (
                      <Badge key={index} variant="outline" className="border-gray-600 text-gray-300">
                        {sponsor}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Event Description */}
                <div className="mt-6">
                  <h4 className="text-white font-semibold mb-2">Event Description:</h4>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {festival.description}
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 mt-6">
                  {!session ? (
                    <Button
                      className="bg-green-400 hover:bg-green-500 text-black font-semibold"
                      onClick={() => router.push('/signup')}
                    >
                      Apply for Sponsorship
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  ) : session.user?.userType === 'sponsor' ? (
                    <Button
                      className="bg-green-400 hover:bg-green-500 text-black font-semibold"
                      onClick={() => setApplyDialog({ open: true, festival })}
                    >
                      Apply for Sponsorship
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  ) : (
                    <Button
                      className="bg-gray-700 text-gray-300 cursor-not-allowed"
                      disabled
                      title="Only sponsors can apply for sponsorship"
                    >
                      Apply for Sponsorship
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    onClick={() => handleDownloadBrochure(festival)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Brochure
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Apply Dialog */}
        <Dialog open={applyDialog.open} onOpenChange={(open) => setApplyDialog({ open, festival: null })}>
          <DialogContent className="max-w-md bg-gray-900 border-gray-700 text-white">
            <DialogHeader>
              <DialogTitle className="text-white">Apply for Sponsorship</DialogTitle>
              <DialogDescription className="text-gray-400">
                Apply to sponsor {applyDialog.festival?.name}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="companyName" className="text-white">
                  Company Name
                </Label>
                <Input
                  id="companyName"
                  placeholder="Your company name"
                  value={applicationForm.companyName}
                  onChange={(e) => setApplicationForm({ ...applicationForm, companyName: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <div>
                <Label htmlFor="email" className="text-white">
                  Contact Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="contact@company.com"
                  value={applicationForm.email}
                  onChange={(e) => setApplicationForm({ ...applicationForm, email: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <div>
                <Label htmlFor="package" className="text-white">
                  Sponsorship Package
                </Label>
                <Select onValueChange={(value) => setApplicationForm({ ...applicationForm, package: value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                    <SelectValue placeholder="Select a package" />
                  </SelectTrigger>
                  <SelectContent 
                    side="bottom" 
                    position="item-aligned" 
                    className="bg-gray-800 border-gray-700"
                  >
                    {applyDialog.festival?.packages.map((pkg) => (
                      <SelectItem key={pkg.name} value={pkg.name} className="text-white">
                        {pkg.name} - {pkg.price}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="message" className="text-white">
                  Message (Optional)
                </Label>
                <Textarea
                  id="message"
                  placeholder="Tell them why you'd like to sponsor this festival..."
                  value={applicationForm.message}
                  onChange={(e) => setApplicationForm({ ...applicationForm, message: e.target.value })}
                  rows={3}
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  className="border-gray-600 text-gray-300"
                  onClick={() => setApplyDialog({ open: false, festival: null })}
                >
                  Cancel
                </Button>
                <Button
                  className="bg-green-400 hover:bg-green-500 text-black"
                  onClick={handleApplyForSponsorship}
                  disabled={!applicationForm.package || !applicationForm.companyName || !applicationForm.email}
                >
                  <Send className="h-4 w-4 mr-2" />
                  Submit Application
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
