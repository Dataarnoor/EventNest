"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Trophy,
  MapPin,
  Clock,
  Users,
  Heart,
  Zap,
  Target,
  Globe,
  Search,
  Briefcase,
  GraduationCap,
  Coffee,
  Gamepad2,
  Plane,
} from "lucide-react"
import Link from "next/link"
import { Navbar } from "@/components/navbar"

export default function CareersPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedDepartment, setSelectedDepartment] = useState("all")
  const [selectedLocation, setSelectedLocation] = useState("all")

  const jobOpenings = [
    {
      id: "1",
      title: "Senior Full Stack Developer",
      department: "Engineering",
      location: "Bangalore",
      type: "Full-time",
      experience: "3-5 years",
      description: "Build and scale our platform that connects thousands of festivals with sponsors across India.",
      requirements: [
        "Strong experience with React, Node.js, and TypeScript",
        "Experience with cloud platforms (AWS/GCP)",
        "Knowledge of database design and optimization",
        "Passion for building user-centric products",
      ],
      posted: "2024-01-15",
      urgent: true,
    },
    {
      id: "2",
      title: "Product Manager - Marketplace",
      department: "Product",
      location: "Bangalore",
      type: "Full-time",
      experience: "4-6 years",
      description: "Lead the product strategy for our marketplace connecting festivals and sponsors.",
      requirements: [
        "4+ years of product management experience",
        "Experience with marketplace or two-sided platforms",
        "Strong analytical and data-driven mindset",
        "Excellent communication and leadership skills",
      ],
      posted: "2024-01-12",
      urgent: false,
    },
    {
      id: "3",
      title: "Partnership Manager",
      department: "Business Development",
      location: "Mumbai",
      type: "Full-time",
      experience: "2-4 years",
      description: "Build and maintain relationships with colleges and sponsors to grow our platform.",
      requirements: [
        "Experience in business development or partnerships",
        "Strong relationship building skills",
        "Understanding of event management industry",
        "Willingness to travel across India",
      ],
      posted: "2024-01-10",
      urgent: false,
    },
    {
      id: "4",
      title: "UI/UX Designer",
      department: "Design",
      location: "Remote",
      type: "Full-time",
      experience: "2-4 years",
      description: "Design intuitive and beautiful experiences for our festival and sponsor users.",
      requirements: [
        "Strong portfolio showcasing web and mobile design",
        "Proficiency in Figma and design systems",
        "Experience with user research and testing",
        "Understanding of accessibility principles",
      ],
      posted: "2024-01-08",
      urgent: false,
    },
    {
      id: "5",
      title: "Data Scientist - AI/ML",
      department: "Engineering",
      location: "Bangalore",
      type: "Full-time",
      experience: "3-5 years",
      description: "Develop AI algorithms for sponsor-festival matching and recommendation systems.",
      requirements: [
        "Strong background in machine learning and statistics",
        "Experience with Python, TensorFlow/PyTorch",
        "Knowledge of recommendation systems",
        "PhD or Masters in relevant field preferred",
      ],
      posted: "2024-01-05",
      urgent: true,
    },
    {
      id: "6",
      title: "Marketing Manager",
      department: "Marketing",
      location: "Delhi",
      type: "Full-time",
      experience: "3-5 years",
      description: "Lead our marketing efforts to reach colleges and sponsors across India.",
      requirements: [
        "Experience in B2B marketing and growth",
        "Strong content creation and campaign management skills",
        "Knowledge of digital marketing channels",
        "Experience in education or events industry preferred",
      ],
      posted: "2024-01-03",
      urgent: false,
    },
  ]

  const benefits = [
    {
      icon: <Heart className="h-8 w-8 text-red-500" />,
      title: "Health & Wellness",
      description: "Comprehensive health insurance, mental health support, and wellness programs",
    },
    {
      icon: <GraduationCap className="h-8 w-8 text-blue-500" />,
      title: "Learning & Development",
      description: "Annual learning budget, conference attendance, and skill development programs",
    },
    {
      icon: <Coffee className="h-8 w-8 text-brown-500" />,
      title: "Work-Life Balance",
      description: "Flexible working hours, remote work options, and unlimited PTO policy",
    },
    {
      icon: <Gamepad2 className="h-8 w-8 text-purple-500" />,
      title: "Fun & Recreation",
      description: "Team outings, game nights, festival celebrations, and recreational activities",
    },
    {
      icon: <Plane className="h-8 w-8 text-green-500" />,
      title: "Travel Opportunities",
      description: "Visit festivals across India, attend conferences, and explore new cities",
    },
    {
      icon: <Trophy className="h-8 w-8 text-yellow-500" />,
      title: "Equity & Growth",
      description: "Employee stock options and clear career progression paths",
    },
  ]

  const values = [
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      title: "Community First",
      description: "We believe in empowering student communities and creating meaningful connections.",
    },
    {
      icon: <Zap className="h-8 w-8 text-yellow-600" />,
      title: "Innovation",
      description: "We constantly push boundaries with technology to solve real-world problems.",
    },
    {
      icon: <Target className="h-8 w-8 text-green-600" />,
      title: "Excellence",
      description: "We strive for excellence in everything we do and exceed expectations.",
    },
    {
      icon: <Globe className="h-8 w-8 text-purple-600" />,
      title: "Impact",
      description: "We measure success by the positive impact we create for our users.",
    },
  ]

  const filteredJobs = jobOpenings.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDepartment = selectedDepartment === "all" || job.department === selectedDepartment
    const matchesLocation = selectedLocation === "all" || job.location === selectedLocation
    return matchesSearch && matchesDepartment && matchesLocation
  })

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(34,197,94,0.1),transparent_50%)]"></div>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-400/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-green-400/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-300 mb-6">
            Join Our{" "}
            <span className="bg-gradient-to-r from-green-400 to-green-300 bg-clip-text text-transparent">Mission</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Help us revolutionize how college festivals connect with sponsors across India. Build the future of event
            partnerships with a passionate team.
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" className="bg-green-400 hover:bg-green-500 text-black font-semibold px-8" asChild>
              <Link href="#openings">View Open Positions</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-green-400 text-green-400 hover:bg-green-400 hover:text-black px-8"
              asChild
            >
              <Link href="#culture">Learn About Our Culture</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Why Join Us */}
      <section id="culture" className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Why Join FestConnect?</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Be part of a mission-driven team that's transforming the events industry in India
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {values.map((value, index) => (
              <Card key={index} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow text-center">
                <CardHeader>
                  <div className="flex justify-center mb-4">{value.icon}</div>
                  <CardTitle className="text-xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-indigo-600 rounded-2xl p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4">Our Impact</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <div className="text-3xl font-bold">2500+</div>
                <div className="text-indigo-200">Festivals Empowered</div>
              </div>
              <div>
                <div className="text-3xl font-bold">₹50Cr+</div>
                <div className="text-indigo-200">Value Created</div>
              </div>
              <div>
                <div className="text-3xl font-bold">500+</div>
                <div className="text-indigo-200">Sponsor Partnerships</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-gray-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Benefits & Perks</h2>
            <p className="text-xl text-gray-400">We take care of our team so they can do their best work</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center mb-4">
                    {benefit.icon}
                    <CardTitle className="text-xl ml-3">{benefit.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Job Openings */}
      <section id="openings" className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Open Positions</h2>
            <p className="text-xl text-gray-400">Find your next opportunity with us</p>
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search positions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400"
                />
              </div>
            </div>
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-full md:w-48 bg-gray-800 border-gray-700 text-white placeholder-gray-400">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700 text-white placeholder-gray-400">
                <SelectItem value="all">All Departments</SelectItem>
                <SelectItem value="Engineering">Engineering</SelectItem>
                <SelectItem value="Product">Product</SelectItem>
                <SelectItem value="Design">Design</SelectItem>
                <SelectItem value="Business Development">Business Development</SelectItem>
                <SelectItem value="Marketing">Marketing</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedLocation} onValueChange={setSelectedLocation}>
              <SelectTrigger className="w-full md:w-48 bg-gray-800 border-gray-700 text-white placeholder-gray-400">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700 text-white placeholder-gray-400">
                <SelectItem value="all">All Locations</SelectItem>
                <SelectItem value="Bangalore">Bangalore</SelectItem>
                <SelectItem value="Mumbai">Mumbai</SelectItem>
                <SelectItem value="Delhi">Delhi</SelectItem>
                <SelectItem value="Remote">Remote</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Job Listings */}
          <div className="space-y-6">
            {filteredJobs.map((job) => (
              <Card key={job.id} className="bg-gray-900 border-gray-800 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <CardTitle className="text-xl">{job.title}</CardTitle>
                        {job.urgent && <Badge className="bg-red-500">Urgent</Badge>}
                      </div>
                      <div className="flex items-center gap-4 text-gray-400">
                        <div className="flex items-center">
                          <Briefcase className="h-4 w-4 mr-1" />
                          {job.department}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {job.location}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {job.type}
                        </div>
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-1" />
                          {job.experience}
                        </div>
                      </div>
                    </div>
                    <Badge variant="outline">Posted {new Date(job.posted).toLocaleDateString()}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 mb-4">{job.description}</p>

                  <div className="mb-4">
                    <h4 className="font-semibold text-white mb-2">Requirements:</h4>
                    <ul className="list-disc list-inside text-gray-400 space-y-1">
                      {job.requirements.map((req, index) => (
                        <li key={index}>{req}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex gap-3">
                    <Button asChild>
                      <Link href={`/careers/${job.id}/apply`}>Apply Now</Link>
                    </Button>
                    <Button variant="outline" asChild>
                      <Link href={`/careers/${job.id}`}>View Details</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredJobs.length === 0 && (
            <div className="text-center py-12">
              <Briefcase className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-400 mb-2">No positions found</h3>
              <p className="text-gray-500 mb-4">Try adjusting your search criteria</p>
              <Button variant="outline" asChild>
                <Link href="mailto:careers@festconnect.in">Send us your resume</Link>
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-indigo-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Don't See the Right Role?</h2>
          <p className="text-xl text-indigo-100 mb-8 max-w-2xl mx-auto">
            We're always looking for talented individuals who share our passion. Send us your resume and let's talk!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="mailto:careers@festconnect.in">Send Your Resume</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-indigo-600"
              asChild
            >
              <Link href="/contact">Get in Touch</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Trophy className="h-6 w-6 text-indigo-400" />
                <span className="ml-2 text-xl font-bold">FestConnect</span>
              </div>
              <p className="text-gray-400">Revolutionizing event partnerships across India.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Careers</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/careers" className="hover:text-white">
                    Open Positions
                  </Link>
                </li>
                <li>
                  <Link href="/careers#culture" className="hover:text-white">
                    Our Culture
                  </Link>
                </li>
                <li>
                  <Link href="/careers#benefits" className="hover:text-white">
                    Benefits
                  </Link>
                </li>
                <li>
                  <Link href="mailto:careers@festconnect.in" className="hover:text-white">
                    careers@festconnect.in
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white">
                    LinkedIn
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Twitter
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Instagram
                  </Link>
                </li>
                <li>
                  <Link href="mailto:hello@festconnect.in" className="hover:text-white">
                    hello@festconnect.in
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 FestConnect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
