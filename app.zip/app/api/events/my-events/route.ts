import { NextResponse } from "next/server";
import connectDB from "@/lib/db";
import Event from "@/models/Event";
import { getServerSession } from "next-auth"; // or your session util
import mongoose from "mongoose";

export async function GET(req) {
  await connectDB();
  const session = await getServerSession(); // adjust for your auth setup
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Debug: log all events and their organizerEmail
  const allEvents = await Event.find({});
  console.log("All events in DB:", allEvents.map(e => ({
    id: e._id,
    title: e.title,
    organizerEmail: e.organizerEmail
  })));

  // Find events for this user (use college field for ownership)
  const events = await Event.find({ college: new mongoose.Types.ObjectId(session.user.id) });

  // Debug: log found events for this user
  console.log("Events for user", session.user.email, ":", events);

  return NextResponse.json({ events }, { status: 200 });
}
